from django.urls import path
from .serializers import *
from .views import *





# Setup the URLs and include login URLs for the browsable API.
urlpatterns = [
    path('', UserList.as_view()),
    path('users/<pk>/', UserDetails.as_view()),
    path('groups/', GroupList.as_view()),
]